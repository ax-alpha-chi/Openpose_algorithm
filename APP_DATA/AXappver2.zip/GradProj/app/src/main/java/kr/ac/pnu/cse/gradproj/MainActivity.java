package kr.ac.pnu.cse.gradproj;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.FFmpegLoadBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegNotSupportedException;

public class MainActivity extends AppCompatActivity {

    FFmpeg fFmpeg;
    private static int VIDEO_REQUEST = 101;
    private Uri videoUri = null;
    ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        try{
            loadFFMpegLibrary();
        }
        catch (FFmpegNotSupportedException e){
            e.printStackTrace();
        }
    }

public void loadFFMpegLibrary() throws FFmpegNotSupportedException{
        if(fFmpeg == null)
        {
            fFmpeg = FFmpeg.getInstance(this);
            fFmpeg.loadBinary(new FFmpegLoadBinaryResponseHandler() {
                @Override
                public void onFailure() {
                }

                @Override
                public void onSuccess() {
                    Toast.makeText(getApplicationContext(), "Sucess",Toast.LENGTH_LONG).show();
                }

                @Override
                public void onStart() {
                }

                @Override
                public void onFinish() {
                }
            });
        }
    }

    public void executeCommand(final String[] command) throws FFmpegCommandAlreadyRunningException{
        fFmpeg.execute(command,new ExecuteBinaryResponseHandler()
        {
            @Override
            public void onFailure(String message){
                super.onFailure(message);
            }
            @Override
            public void onFinish(){
                super.onFinish();
            }
            @Override
            public void onProgress(String message){
                super.onProgress(message);
            }
            @Override
            public void onStart(){
                super.onStart();
            }
            @Override
            public void onSuccess(String message){
                super.onSuccess(message);
            }
        });
}



    public void captureVideo(View view) {

        Intent videoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        image = (ImageView) findViewById(R.id.image);

        if (videoIntent.resolveActivity(getPackageManager()) != null) {
            videoIntent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 10);
            startActivityForResult(videoIntent, VIDEO_REQUEST);
        }

   }


 public void playVideo(View view)
        {
            Intent playIntent = new Intent(this,VideoPlayActivity.class);
            playIntent.putExtra("videoUri", videoUri.toString());
            startActivity(playIntent);
        }


        @Override
                protected void onActivityResult(int requestCode, int resultCode, Intent data){
            if(requestCode==VIDEO_REQUEST && resultCode==RESULT_OK)
            {
                videoUri = data.getData();

            }
        }
    }
