package kr.ac.pnu.cse.gradproj;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ResultsActivity extends AppCompatActivity {
    File file;
    File file2;
    File file3;
    Dialog myDialog;

    private MyFTPClientFunctions ftpclient = null;
    ImageView download;
    ImageView video;
    Button button;
    public void ShowPopup() {
        //Toast.makeText(this,"lol",Toast.LENGTH_SHORT).show();
        myDialog.setContentView(R.layout.popup_window);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        file = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt");
        TextView Result_txt;
        //Read text from file
        StringBuilder text = new StringBuilder();

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
        }
        catch (IOException e) {
            //You'll need to add proper error handling here
        }

//Find the view by its id
        Result_txt = (TextView)myDialog.findViewById(R.id.Result1);

//Set the text
        Result_txt.setText(text);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myDialog = new Dialog(this);
        setContentView(R.layout.activity_results);
        file2 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/processed.gif");
        file3 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt");
        ftpclient = new MyFTPClientFunctions();
//Get the text file

        download = (ImageView) findViewById(R.id.download);
        button = (Button)findViewById(R.id.Resultbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowPopup();
            }
        });
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","processed.gif",file2);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
        video = (ImageView) findViewById(R.id.result_norm);
        video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Glide
                        .with(ResultsActivity.this).asGif()
                        .load(file2)
                        .into(video);
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","result.txt",file3);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });


    }
}
