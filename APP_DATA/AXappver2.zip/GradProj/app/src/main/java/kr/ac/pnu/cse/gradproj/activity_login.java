package kr.ac.pnu.cse.gradproj;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class activity_login extends AppCompatActivity {

    private ImageView imgView_logo ;
    RelativeLayout rellay1, line2;
    Handler handler = new Handler();
    Runnable runnavle = new Runnable() {
        @Override
        public void run() {
            rellay1.setVisibility(View.VISIBLE);
            line2.setVisibility(View.VISIBLE);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        rellay1 = (RelativeLayout) findViewById(R.id.rellay1);
        line2 = (RelativeLayout) findViewById(R.id.rellay2);
        handler.postDelayed(runnavle, 2000);

        imgView_logo = (ImageView) findViewById(R.id.imgView_logo);
        imgView_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });
    }

    public void openActivity2() {
        Intent intent = new Intent(this, infoStart.class);
        startActivity(intent);
    }
}

