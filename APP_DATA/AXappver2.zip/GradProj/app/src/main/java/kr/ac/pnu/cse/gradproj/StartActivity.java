package kr.ac.pnu.cse.gradproj;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import java.io.File;
import java.io.IOException;


public class StartActivity extends AppCompatActivity {

    private MyFTPClientFunctions ftpclient = null;
    private static int VIDEO_REQUEST = 101;
    public ImageView camera, upload ;
    ImageView image;
    ImageView imgPreview;
    private static final int MY_PERMISSIONS_REQUEST = 100;

    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        ftpclient = new MyFTPClientFunctions();
        requestStoragePermission();
        upload = (ImageView) findViewById(R.id.upload);
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    public void run() {
                        ftpclient.ftpConnect("3.19.139.163","ilona","Nar340536!",21);
                        ftpclient.ftpUpload("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/tobeprocessed.mp4","tobeprocessed.mp4","/",StartActivity.this);
                    }
                }).start();

            }
        });

    }
    String currentVideoPath;
    private File createVideoFile()throws IOException {
        // Create an image file name
        File video = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/tobeprocessed.mp4");
        // Save a file: path for use with ACTION_VIEW intents
        currentVideoPath = video.getAbsolutePath();
        return video;
    }
    File file;
    public void captureVideo(View view) {

        Intent videoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);

        if (videoIntent.resolveActivity(getPackageManager()) != null) {
            try {
                file = createVideoFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (file != null) {
                Uri videoURI = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        file);
                videoIntent.putExtra(MediaStore.EXTRA_OUTPUT, videoURI);
                videoIntent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
                videoIntent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 10);
                startActivityForResult(videoIntent, VIDEO_REQUEST);
            }
        }
    }
}