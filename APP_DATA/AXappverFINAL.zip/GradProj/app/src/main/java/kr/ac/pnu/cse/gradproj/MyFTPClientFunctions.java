package kr.ac.pnu.cse.gradproj;

import android.content.Context;
import android.util.Log;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MyFTPClientFunctions {

	// Now, declare a public FTP client object.

	private static final String TAG = "MyFTPClientFunctions";
	static public FTPClient mFTPClient = null;

	// Method to connect to FTP server:
	public boolean ftpConnect(String host, String username, String password,
			int port) {
		try {
			mFTPClient = new FTPClient();
			// connecting to the host
			mFTPClient.connect(host, port);

			// now check the reply code, if positive mean connection success
			if (FTPReply.isPositiveCompletion(mFTPClient.getReplyCode())) {
				// login using username & password
				boolean status = mFTPClient.login(username, password);

				/*
				 * Set File Transfer Mode
				 * 
				 * To avoid corruption issue you must specified a correct
				 * transfer mode, such as ASCII_FILE_TYPE, BINARY_FILE_TYPE,
				 * EBCDIC_FILE_TYPE .etc. Here, I use BINARY_FILE_TYPE for
				 * transferring text, image, and compressed files.
				 */
				mFTPClient.setFileType(FTP.BINARY_FILE_TYPE);
				mFTPClient.enterLocalPassiveMode();

				return status;
			}
		} catch (Exception e) {
			Log.d(TAG, "Error: could not connect to host " + host);
		}

		return false;
	}


	public Boolean downloadAndSaveFile(String server, int portNumber,
										String user, String password, String filename, File localFile)
			throws IOException {
		FTPClient ftp = null;

		try {
			ftp = new FTPClient();
			ftp.connect(server, portNumber);
			Log.d(TAG, "Connected. Reply: " + ftp.getReplyString());

			ftp.login(user, password);
			Log.d(TAG, "Logged in");
			ftp.setFileType(FTP.BINARY_FILE_TYPE);
			Log.d(TAG, "Downloading");
			ftp.enterLocalPassiveMode();

			OutputStream outputStream = null;
			boolean success = false;
			try {
				outputStream = new BufferedOutputStream(new FileOutputStream(
						localFile));
				success = ftp.retrieveFile(filename, outputStream);
			} finally {
				if (outputStream != null) {
					outputStream.close();
				}
			}
			return success;
		} finally {
			if (ftp != null) {
				ftp.logout();
				ftp.disconnect();
			}
		}
	}
	// Method to upload a file to FTP server:

	/**
	 * mFTPClient: FTP client connection object (see FTP connection example)
	 * srcFilePath: source file path in sdcard desFileName: file name to be
	 * stored in FTP server desDirectory: directory path where the file should
	 * be upload to
	 */
	public boolean ftpUpload(String srcFilePath, String desFileName,
			String desDirectory, Context context) {
		boolean status = false;
		try {
			FileInputStream srcFileStream = new FileInputStream(srcFilePath);

			// change working directory to the destination directory
			// if (ftpChangeDirectory(desDirectory)) {
			status = mFTPClient.storeFile(desFileName, srcFileStream);
			// }

			srcFileStream.close();

			return status;
		} catch (Exception e) {
			e.printStackTrace();
			Log.d(TAG, "upload failed: " + e);
		}

		return status;
	}
}