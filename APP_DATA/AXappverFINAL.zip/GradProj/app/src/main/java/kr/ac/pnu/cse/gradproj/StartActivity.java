package kr.ac.pnu.cse.gradproj;

import android.Manifest;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import static android.content.DialogInterface.*;


public class StartActivity extends AppCompatActivity {

    private MyFTPClientFunctions ftpclient = null;
    private static int VIDEO_REQUEST = 101;
    public ImageView camera, upload ;
    ImageView image;
    Dialog myDialog;
    String link;
    ImageView imgPreview;
    TextView inst1;
    TextView inst2;
    TextView inst3;
    int i = 0;
    File file2;
    Button showsample;

    private static final int MY_PERMISSIONS_REQUEST = 100;

    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        ftpclient = new MyFTPClientFunctions();
        requestStoragePermission();
        myDialog = new Dialog(this);
        showsample = (Button) findViewById(R.id.showvideo);
        file2 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt");
        inst1 = (TextView)findViewById(R.id.Instruction1);
        inst2 = (TextView)findViewById(R.id.Instruction2);
        inst3 = (TextView)findViewById(R.id.Instruction3);
        upload = (ImageView) findViewById(R.id.upload);
        showsample.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowPopup5(i);
            }
        });
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    public void run() {
                        ftpclient.ftpConnect("3.19.139.163","ilona","Nar340536!",21);
                        ftpclient.ftpUpload("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/tobeprocessed.mp4","tobeprocessed.mp4","/",StartActivity.this);
                    }
                }).start();
                ShowPopup4();

            }
        });

    }
    String currentVideoPath;
    private File createVideoFile()throws IOException {
        // Create an image file name
        File video = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/tobeprocessed.mp4");
        // Save a file: path for use with ACTION_VIEW intents
        currentVideoPath = video.getAbsolutePath();
        return video;
    }
    File file;
    public void captureVideo(View view) {

        Intent videoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);

        if (videoIntent.resolveActivity(getPackageManager()) != null) {
            try {
                file = createVideoFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (file != null) {
                Uri videoURI = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        file);
                videoIntent.putExtra(MediaStore.EXTRA_OUTPUT, videoURI);
                videoIntent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
                videoIntent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 10);
                startActivityForResult(videoIntent, VIDEO_REQUEST);
            }
        }
    }
    public void onRadioButtonClicked(View view) throws IOException {
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.front:
                if (checked){
                    i = 0;
                    inst1.setText("Front Squat\n" +
                            "\n" +
                            "Try to perform exercise on plain and light background. Cloth should be not boxy-fit because its will be difficult for program to identify your body lines. If background happen to be plain dark, then cloth should be one or two tones lighter for the best results and vice-versa.\n" +
                            "Please capture video so you appear not from too much high or low angle. Program has to calculate your approximate height to make best recommendations. For convenience ask someone to help you record video or properly set the camera to record referring to the above said.\n" +
                            "Try to squat as deep as you can.\n" +
                            "Enjoy your personal AX trainer.");
                    inst2.setText("");
                    inst3.setText("");
                    FileOutputStream stream = new FileOutputStream(file2);
                    try {
                        stream.write("f".getBytes());
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        stream.close();
                    }
                    new Thread(new Runnable() {
                        public void run() {
                            ftpclient.ftpConnect("3.19.139.163","ilona","Nar340536!",21);
                            ftpclient.ftpUpload("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt","result.txt","/",StartActivity.this);
                        }
                    }).start();

                }
                    // Pirates are the best
                    break;
            case R.id.side:
                if (checked){
                    i = 1;
                    inst1.setText("");
                    inst2.setText("Side Squat\n" +
                            "\n" +
                            "When performnig the side squat please follow these guidelines. If background happen to be plain dark, then cloth should be one or two tones lighter for the best results and vice-versa.\n" +
                            "Please capture video in a way so you appear not from too much high or low angle. Program has to calculate your approximate height to make best recommendations. For convenience ask someone to help you record video or properly set the camera to record referring to the above said.\n" +
                            "Try to squat as deep as you can.\n" +
                            "Enjoy your personal AX trainer.");
                    inst3.setText("");
                    FileOutputStream stream = new FileOutputStream(file2);
                    try {
                        stream.write("s".getBytes());
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        stream.close();
                    }
                    new Thread(new Runnable() {
                        public void run() {
                            ftpclient.ftpConnect("3.19.139.163","ilona","Nar340536!",21);
                            ftpclient.ftpUpload("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt","result.txt","/",StartActivity.this);
                        }
                    }).start();


                }
                    // Ninjas rule
                    break;
            case R.id.plank:
                if (checked){
                    i = 2;
                    inst1.setText("");
                    inst2.setText("");
                    inst3.setText("Plank\n" +
                            "\n" +
                            "Try to perform exercise on plain and light background. Cloth should be not boxy-fit because its will be difficult for program to identify your body lines. If background happen to be plain dark, then cloth should be one or two tones lighter for the best results and vice-versa.\n" +
                            "Please capture video in a way so you appear not from too much high or low angle. Otherwise data will be read wrong and it may effect on result and recommendations for better exercise performance.  For convenience ask someone to help you record video or properly set the camera to record referring to the above said.\n" +
                            "Enjoy your personal AX trainer.");
                    FileOutputStream stream = new FileOutputStream(file2);
                    try {
                        stream.write("p".getBytes());
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        stream.close();
                    }
                    new Thread(new Runnable() {
                        public void run() {
                            ftpclient.ftpConnect("3.19.139.163","ilona","Nar340536!",21);
                            ftpclient.ftpUpload("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt","result.txt","/",StartActivity.this);
                        }
                    }).start();

                }
                    // Ninjas rule
                    break;
        }

    }
    public void ShowPopup4() {
        //Toast.makeText(this,"lol",Toast.LENGTH_SHORT).show();
        myDialog.setContentView(R.layout.popup_window4);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }
    public void ShowPopup5(int i) {

        if( i == 0)
            link = "https://youtu.be/mGvzVjuY8SY?t=284";
        if( i == 1)
            link = "https://youtu.be/t8y57QbLAZs?t=1";
        if( i == 2)
            link = "https://youtu.be/pvIjsG5Svck?t=1";


        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setPackage("com.google.android.youtube");
        startActivity(intent);
    }
}

