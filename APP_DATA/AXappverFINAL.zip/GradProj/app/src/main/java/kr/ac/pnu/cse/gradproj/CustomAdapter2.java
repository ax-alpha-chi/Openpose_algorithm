package kr.ac.pnu.cse.gradproj;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

class CustomAdapter2 extends ArrayAdapter {
    ArrayList<SubjectData> arrayList;
    Context context;
    private LayoutInflater inflater;

    public CustomAdapter2(Context context, ArrayList<SubjectData> arrayList) {
        super(context, R.layout.activity_adapter_detailed_result, arrayList);

        this.context = context;
        this.arrayList = arrayList;
        inflater = LayoutInflater.from(context);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        SubjectData subjectData = arrayList.get(position);
        if(convertView == null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView = layoutInflater.inflate(R.layout.activity_adapter_detailed_result, null);
            TextView tittle = convertView.findViewById(R.id.textView);
            ImageView imag1 = convertView.findViewById(R.id.imageView1);
            ImageView imag2 = convertView.findViewById(R.id.imageView2);
            tittle.setText(subjectData.SubjectName);
            Glide.with(context)
                    .load(subjectData.video)
                    .into(imag1);
            Glide.with(context)
                    .load(subjectData.sample)
                    .into(imag2);
        }
        return convertView;
    }
}