package kr.ac.pnu.cse.gradproj;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import static java.lang.Thread.sleep;
import static kr.ac.pnu.cse.gradproj.activity_login.googleAccount;
import static kr.ac.pnu.cse.gradproj.infoStart.myRef;
import static kr.ac.pnu.cse.gradproj.infoStart.onlineSize;

public class ResultsActivity extends AppCompatActivity {
    static File file;
    static File file2;
    static File file3;
    static File file4;
    static File error1;
    static File error2;
    static File error3;
    static File error4;
    static File error5;
    static File error6;
    static File error7;
    static File error8;
    static File file13;
    static File file14;
    static File file15;
    static File file16;
    static File file17;
    static File file18;
    static File file19;
    static File file20;

    Dialog myDialog;
    LinearLayout layout;
    AlertDialog ad;
    TextView tv1;
    public static FirebaseStorage storage = FirebaseStorage.getInstance();
    private MyFTPClientFunctions ftpclient = null;
    ImageView download;
    ImageView video;
    ImageView video2;
    Button dresults;
    Button button;
    Button uploadbutton;
    StringBuilder text;
    TextView result2;
    public void ShowPopup() {
        file = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt");
        text = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            int count = 0;
            int stop = 0;
            while ((line = br.readLine()) != null) {
                if(stop == 0) {
                    if (text.equals("data\n")) {
                        break;
                    }
                    if (count % 4 != 0) {
                        text.append(line);
                        text.append('\n');
                    }
                    count++;
                }
            }
            br.close();
        }
        catch (IOException e) {
        }
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Result");
        alert.setMessage(text);
        final TextView input = new TextView (this);
        alert.setView(input);
        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        alert.show();
    }
    Thread t1 = new Thread (new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","result.txt",file3);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t2 = new Thread (new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","processed.gif",file2);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t3 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","processed2.gif",file4);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t4 = new Thread (new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","error1.jpg",error1);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t5 = new Thread (new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","error2.jpg",error2);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t6 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","error3.jpg",error3);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t7 = new Thread (new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","error4.jpg",error4);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t8 = new Thread (new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","error5.jpg",error5);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t9 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","error6.jpg",error6);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t10 = new Thread (new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","error7.jpg",error7);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t11 = new Thread (new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","error8.jpg",error8);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t12 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","stand0.jpg",file13);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t13 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","stand1.jpg",file14);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t14 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","stand2.jpg",file15);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t15 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","stand3.jpg",file16);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t16 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","squat0.jpg",file17);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t17 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","squat1.jpg",file18);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t18 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","squat2.jpg",file19);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    Thread t19 = new Thread(new Runnable() {
        public void run() {
            try {
                ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","squat3.jpg",file20);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myDialog = new Dialog(this);
        setContentView(R.layout.activity_results);
        file2 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/processed.gif");
        file3 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt");
        file4 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/processed2.gif");
        error1 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/error1.jpg");
        error2 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/error2.jpg");
        error3 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/error3.jpg");
        error4 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/error4.jpg");
        error5 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/error5.jpg");
        error6 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/error6.jpg");
        error7 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/error7.jpg");
        error8 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/error8.jpg");
        file13 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/stand0.jpg");
        file14 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/stand1.jpg");
        file15 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/stand2.jpg");
        file16 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/stand3.jpg");
        file17 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/squat0.jpg");
        file18 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/squat1.jpg");
        file19 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/squat2.jpg");
        file20 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/squat3.jpg");
        ftpclient = new MyFTPClientFunctions();
        result2 = (TextView)findViewById(R.id.result2);
//Get the text file
        download = (ImageView) findViewById(R.id.download);
        dresults = (Button)findViewById(R.id.detailsbtn);
        button = (Button)findViewById(R.id.Resultbtn);
        uploadbutton = (Button)findViewById(R.id.Uploadbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowPopup();
            }
        });
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ShowPopup6();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        });
        video = (ImageView) findViewById(R.id.result_norm);
        video2 = (ImageView) findViewById(R.id.result_skeleton);
        video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Glide
                        .with(ResultsActivity.this)
                        .load(file2)
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .into(video);
                Glide
                        .with(ResultsActivity.this)
                        .load(file4)
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .into(video2);
            }
        });
        video2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showPopup7();
            }
        });
        uploadbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StorageReference storageRef = storage.getReference();
                final int size = Integer.parseInt(onlineSize);
                StorageReference mountainsRef = storageRef.child(size + ".gif");
                Uri file = Uri.fromFile(new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/processed.gif"));
                UploadTask uploadTask = mountainsRef.putFile(file);
                onlineSize = Integer.toString(size + 1 ) ;
                myRef.setValue(onlineSize);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                        updatelocation(size);
                        // ...
                    }
                });
                ShowPopup4();
            }
        });
        dresults.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenActivity();
            }
        });
    }
    void updatelocation(int size){
        StorageReference storageRef1 = FirebaseStorage.getInstance().getReference(size + ".gif");
        StorageMetadata metadata = new StorageMetadata.Builder()
                .setContentType("image/gif")
                .setCustomMetadata("commentsize","0")
                .setCustomMetadata("uploader",googleAccount.getDisplayName())
                .build();
        storageRef1.updateMetadata(metadata)
                .addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                    @Override
                    public void onSuccess(StorageMetadata storageMetadata) {
                        // Updated metadata is in storageMetadata
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Uh-oh, an error occurred!
                    }
                });
    }
    public void ShowPopup4() {
        //Toast.makeText(this,"lol",Toast.LENGTH_SHORT).show();
        myDialog.setContentView(R.layout.popup_window4);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }
    public void OpenActivity(){
        Intent openresult ;
        openresult = new Intent(this, Detailed_Result_Activity.class);
        startActivity(openresult);
    }
    public void ShowPopup6() throws InterruptedException {
        //Toast.makeText(this,"lol",Toast.LENGTH_SHORT).show();
        int s = 1000;
        myDialog.setContentView(R.layout.popup_window6);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
        sleep(s);
        t1.start();
        try {
            t1.join();
            sleep(s);
        } catch (InterruptedException e) {
            e.printStackTrace();

        }
        t2.start();
        try {
            t2.join();
            sleep(s);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        t3.start();
        try {
            t3.join();
            sleep(s);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
    public void showPopup7(){
        int s = 1000;
        try {
            t4.start();
            sleep(s);
            t5.start();
            sleep(s);
            t6.start();
            sleep(s);
            t7.start();
            sleep(s);
            t8.start();
            sleep(s);
            t9.start();
            sleep(s);
            t10.start();
            sleep(s);
            t11.start();
            sleep(s);
            t12.start();
            sleep(s);
            t13.start();
            sleep(s);
            t14.start();
            sleep(s);
            t15.start();
            sleep(s);
            t16.start();
            sleep(s);
            t17.start();
            sleep(s);
            t18.start();
            sleep(s);
            t19.start();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

