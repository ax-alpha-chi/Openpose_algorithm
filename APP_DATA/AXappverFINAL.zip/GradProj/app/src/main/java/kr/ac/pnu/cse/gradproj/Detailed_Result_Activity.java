package kr.ac.pnu.cse.gradproj;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import com.bumptech.glide.Glide;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class Detailed_Result_Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        StringBuilder text;
        File file;
        int count = 0;
        StringBuilder code;
        Button databutton;
        ImageView sample;
        setContentView(R.layout.activity_detailed__result_);
        final ListView list = findViewById(R.id.simpleListView);
        ArrayList<SubjectData> arrayList = new ArrayList<SubjectData>();
        ArrayList<String> errorList = new ArrayList<String>();
        ArrayList<File> videoList = new ArrayList<File>();
        ArrayList<File> sampleList = new ArrayList<File>();
        super.onCreate(savedInstanceState);
        file = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt");
        text = new StringBuilder();
        code = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                if(line.equals("data"))
                    break;
                if((count > 3)) {
                    if(count %4 != 0) {
                        text.append(line);
                        text.append('\n');
                        if ((count-3) % 4 == 0) {
                            errorList.add(text.toString());
                            text.setLength(0);
                        }
                    }
                    else{
                        code.append(line);
                        code.append('\n');
                    }
                }
                count++;
            }
            br.close();
        }
        catch (IOException e) {
        }
        databutton = (Button) findViewById(R.id.data);
        databutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendataactvity();
            }
        });
        String[] lines = code.toString().split(System.getProperty("line.separator"));
        int numberofmistakes = lines.length;
        for(int i = 0; i < numberofmistakes; i++){
            videoList.add(i,new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/error" + (i+1) + ".jpg"));
            sampleList.add(i,new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/error" + (i+1) + ".jpg"));
            if(lines[i].equals((i+1) + "F")){
                sampleList.add(i,new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/F.jpg"));
            }
            if(lines[i].equals((i+1) + "HU")){
                sampleList.add(i,new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/HU.jpg"));
            }
            if(lines[i].equals((i+1) + "HD")){
                sampleList.add(i,new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/HD.jpg"));
            }
            if(lines[i].equals((i+1) + "K")){
                sampleList.add(i,new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/K.jpg"));
            }
            if(lines[i].equals((i+1) + "SU")){
                sampleList.add(i,new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/SU.jpg"));
            }
            if(lines[i].equals((i+1) + "SD")){
                sampleList.add(i,new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/SD.jpg"));
            }
        }
        for(int i = 0; i < errorList.size(); i++)
            arrayList.add(new SubjectData(errorList.get(i),sampleList.get(i),videoList.get(i)));
        list.setAdapter(
                new CustomAdapter(
                        this,
                        arrayList
                )
        );
        sample = (ImageView) findViewById(R.id.video);
        Glide.with(this).load(new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/processed2.gif")).into(sample);
    }
    public void opendataactvity(){
        Intent intent = new Intent(this, Data_Activity.class);
        startActivity(intent);
    }

}
class SubjectData {
    String SubjectName;
    File sample;
    File video;
    public SubjectData(String subjectName,File sample, File video) {
        this.SubjectName = subjectName;
        this.sample = sample;
        this.video = video;
    }
}