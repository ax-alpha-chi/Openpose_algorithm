package kr.ac.pnu.cse.gradproj;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.ui.storage.images.FirebaseImageLoader;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.StorageMetadata;


import static kr.ac.pnu.cse.gradproj.OnlineActivity.arraystorage;
import static kr.ac.pnu.cse.gradproj.activity_login.googleAccount;


public class PhotoOnlineActivity extends AppCompatActivity {
    private ImageView imageView1;
    public TextView nametext;
    public TextView loctext;
    Dialog myDialog;
    int post;
    int commentsize;
    public Button cmtBtn;
    public Button seecmtBtn;
    public Button infoBtn;
    public Button mapBtn;
    double lat;
    double longi;
    String newcomment;
    String comment0;
    String comment1;
    String comment2;
    String comment3;
    String username;
    TextView tcomment0;
    TextView tcomment1;
    TextView tcomment2;
    TextView tcomment3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onlinephoto);

        cmtBtn = (Button) findViewById(R.id.cmtBtn);
        myDialog = new Dialog(this);
        infoBtn = (Button) findViewById(R.id.infoBtn);
        imageView1 = (ImageView) findViewById(R.id.imageview1);
        tcomment0 = (TextView) findViewById(R.id.comment0);
        tcomment1 = (TextView) findViewById(R.id.comment1);
        tcomment2 = (TextView) findViewById(R.id.comment2);
        tcomment3 = (TextView) findViewById(R.id.comment3);
        final Intent intent = getIntent();
        final int position = intent.getIntExtra("filename", 0);
        retreivedata(position);
        setTitle("Photo " + position);
        Glide.with(this)
                .load(arraystorage[position])
                .into(imageView1);
        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast();
            }
        });
        cmtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popUpEditText(position);
                try {
                    //set time in mili
                    Thread.sleep(1000);

                }catch (Exception e){
                    e.printStackTrace();
                }
                toast();
            }
        });
        infoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowPopup("Squat Gif");
            }
        });

    }
    void retreivedata(int position){
        arraystorage[position].getMetadata().addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
            @Override
            public void onSuccess(StorageMetadata storageMetadata) {
                commentsize = Integer.parseInt(storageMetadata.getCustomMetadata("commentsize"));
                comment0 = storageMetadata.getCustomMetadata("comment0");
                comment1 = storageMetadata.getCustomMetadata("comment1");
                comment2 = storageMetadata.getCustomMetadata("comment2");
                comment3 = storageMetadata.getCustomMetadata("comment3");
                username = storageMetadata.getCustomMetadata("uploader");
            }


        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Uh-oh, an error occurred!
            }
        });
    }
    void toast(){
        tcomment0.setText(comment0);
        tcomment1.setText(comment1);
        tcomment2.setText(comment2);
        tcomment3.setText(comment3);
    }
    public void ShowPopup(String name) {

        myDialog.setContentView(R.layout.popup_window3);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView nametext;
        TextView usernametext;
        nametext =(TextView) myDialog.findViewById(R.id.name);
        usernametext =(TextView) myDialog.findViewById(R.id.username);
        nametext.setText("Name: " + name);
        usernametext.setText("Uploaded by: " + username);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }
    private void popUpEditText(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Write a comment");

        final EditText input = new EditText(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        input.setLayoutParams(lp);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // do something here on OK
                newcomment = input.getText().toString();
                if(commentsize == 4)
                    rearrange(position);
                else{
                    commentsize++;
                    uploadcomment(position);}


                try {
                    //set time in mili
                    Thread.sleep(1000);

                }catch (Exception e){
                    e.printStackTrace();
                }
                retreivedata(position);
                try {
                    //set time in mili
                    Thread.sleep(1000);

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();

    }
    void rearrange(int position){
        StorageMetadata metadata = new StorageMetadata.Builder()
                .setCustomMetadata("comment0", comment1)
                .setCustomMetadata("comment1", comment2)
                .setCustomMetadata("comment2", comment3)
                .setCustomMetadata("comment3" , googleAccount.getDisplayName() + ":" + newcomment)
                .build();
        arraystorage[position].updateMetadata(metadata)
                .addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                    @Override
                    public void onSuccess(StorageMetadata storageMetadata) {
                        // Updated metadata is in storageMetadata
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Uh-oh, an error occurred!
                    }
                });
    }
    void uploadcomment(int position){
        StorageMetadata metadata = new StorageMetadata.Builder()
                .setCustomMetadata("comment" + (commentsize - 1) , googleAccount.getDisplayName() + ":  " + newcomment)
                .setCustomMetadata("commentsize" , Integer.toString(commentsize) )
                .build();
        arraystorage[position].updateMetadata(metadata)
                .addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                    @Override
                    public void onSuccess(StorageMetadata storageMetadata) {
                        // Updated metadata is in storageMetadata
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Uh-oh, an error occurred!
                    }
                });
    }
}
