package kr.ac.pnu.cse.gradproj;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Data_Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        StringBuilder text;
        File file;
        int count = 0;
        StringBuilder code;
        TextView data;
        setContentView(R.layout.activity_data);
        super.onCreate(savedInstanceState);
        file = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt");
        text = new StringBuilder();
        code = new StringBuilder();
        int start = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                if(line.equals("data"))
                    start = 1;
                if(start == 1){
                    text.append(line);
                    text.append('\n');
                }

            }
            br.close();
        }
        catch (IOException e) {
        }
        data =(TextView)findViewById(R.id.datatext);
        data.setText(text);
        ImageView squat1 = (ImageView) findViewById(R.id.squat1);
        ImageView squat2 = (ImageView) findViewById(R.id.squat2);
        ImageView squat3 = (ImageView) findViewById(R.id.squat3);
        ImageView stand1 = (ImageView) findViewById(R.id.stand1);
        ImageView stand2 = (ImageView) findViewById(R.id.stand2);
        ImageView stand3 = (ImageView) findViewById(R.id.stand3);
        Glide.with(this).load(new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/squat0.jpg")).into(squat1);
        Glide.with(this).load(new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/squat1.jpg")).into(squat2);
        Glide.with(this).load(new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/squat2.jpg")).into(squat3);
        Glide.with(this).load(new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/stand0.jpg")).into(stand1);
        Glide.with(this).load(new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/stand1.jpg")).into(stand2);
        Glide.with(this).load(new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/stand2.jpg")).into(stand3);
    }
}
