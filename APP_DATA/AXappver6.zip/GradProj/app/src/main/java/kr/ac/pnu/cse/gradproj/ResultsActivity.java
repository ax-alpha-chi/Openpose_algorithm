package kr.ac.pnu.cse.gradproj;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import static kr.ac.pnu.cse.gradproj.activity_login.googleAccount;
import static kr.ac.pnu.cse.gradproj.infoStart.myRef;
import static kr.ac.pnu.cse.gradproj.infoStart.onlineSize;

public class ResultsActivity extends AppCompatActivity {
    File file;
    File file2;
    File file3;
    File file4;
    Dialog myDialog;
    LinearLayout layout;
    AlertDialog ad;
    TextView tv1;
    public static FirebaseStorage storage = FirebaseStorage.getInstance();
    private MyFTPClientFunctions ftpclient = null;
    ImageView download;
    ImageView video;
    ImageView video2;
    Button dresults;
    Button button;
    Button uploadbutton;
    StringBuilder text;
    TextView result2;
    public void ShowPopup() {
        //Toast.makeText(this,"lol",Toast.LENGTH_SHORT).show();

        TextView Result_txt;
        file = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt");


        //Read text from file
        text = new StringBuilder();

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
        }
        catch (IOException e) {
            //You'll need to add proper error handling here
        }

//Find the view by its id
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Result");
        alert.setMessage(text);
// Create TextView
        final TextView input = new TextView (this);
        alert.setView(input);

        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Do something with value!
            }
        });
        alert.show();


//Set the text



    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myDialog = new Dialog(this);
        setContentView(R.layout.activity_results);
        file2 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/processed.gif");
        file3 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/result.txt");
        file4 = new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/processed2.gif");
        ftpclient = new MyFTPClientFunctions();
        result2 = (TextView)findViewById(R.id.result2);
//Get the text file
        download = (ImageView) findViewById(R.id.download);
        dresults = (Button)findViewById(R.id.detailsbtn);
        button = (Button)findViewById(R.id.Resultbtn);
        uploadbutton = (Button)findViewById(R.id.Uploadbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowPopup();
            }
        });
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","processed.gif",file2);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
        video = (ImageView) findViewById(R.id.result_norm);
        video2 = (ImageView) findViewById(R.id.result_skeleton);
        video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Glide
                        .with(ResultsActivity.this)
                        .load(file2)
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .into(video);
                Glide
                        .with(ResultsActivity.this)
                        .load(file4)
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .into(video2);
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","result.txt",file3);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
        video2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Thread(new Runnable() {
                    public void run() {
                        try {
                            ftpclient.downloadAndSaveFile("3.19.139.163",21,"ilona","Nar340536!","processed2.gif",file4);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();

            }
        });
        uploadbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StorageReference storageRef = storage.getReference();
                final int size = Integer.parseInt(onlineSize);
                StorageReference mountainsRef = storageRef.child(size + ".gif");
                Uri file = Uri.fromFile(new File("/storage/emulated/0/Android/data/kr.ac.pnu.cse.gradproj/files/Movies/processed.gif"));
                UploadTask uploadTask = mountainsRef.putFile(file);
                onlineSize = Integer.toString(size + 1 ) ;
                myRef.setValue(onlineSize);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                        updatelocation(size);
                        // ...
                    }
                });
                ShowPopup4();
            }
        });
        dresults.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenActivity();
            }
        });
    }
    void updatelocation(int size){
        StorageReference storageRef1 = FirebaseStorage.getInstance().getReference(size + ".gif");
        StorageMetadata metadata = new StorageMetadata.Builder()
                .setContentType("image/gif")
                .setCustomMetadata("commentsize","0")
                .setCustomMetadata("uploader",googleAccount.getDisplayName())
                .build();
        storageRef1.updateMetadata(metadata)
                .addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                    @Override
                    public void onSuccess(StorageMetadata storageMetadata) {
                        // Updated metadata is in storageMetadata
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Uh-oh, an error occurred!
                    }
                });
    }
    public void ShowPopup4() {
        //Toast.makeText(this,"lol",Toast.LENGTH_SHORT).show();
        myDialog.setContentView(R.layout.popup_window4);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }
    public void OpenActivity(){
        Intent openresult ;
        openresult = new Intent(this, Detailed_Result_Activity.class);
        startActivity(openresult);
    }
}
