package kr.ac.pnu.cse.gradproj;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Detailed_Result_Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ListView simpleList;
        String countryList[] = {"India", "China", "australia", "Portugle", "America", "NewZealand","India", "China", "australia", "Portugle", "America"};
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed__result_);
        {
            simpleList = (ListView)
                    findViewById(R.id.simpleListView);
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.activity_adapter_detailed_result, R.id.textView, countryList);
            simpleList.setAdapter(arrayAdapter);
        }
    }
}