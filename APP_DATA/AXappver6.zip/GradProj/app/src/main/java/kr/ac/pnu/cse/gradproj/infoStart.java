package kr.ac.pnu.cse.gradproj;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import static kr.ac.pnu.cse.gradproj.activity_login.googleAccount;
import static kr.ac.pnu.cse.gradproj.activity_login.googleSignInClient;



public class infoStart extends AppCompatActivity {
    ImageView profilepic;
    static DatabaseReference myRef;
    static public FirebaseDatabase database;
    public static String onlineSize;
    private Button A, B, C, communitybtn;
    public static FirebaseAuth mAuth = FirebaseAuth.getInstance();
    Button signOut;
    Dialog myDialog;
    public static final String GOOGLE_ACCOUNT = "google_account";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_start);
        myDialog = new Dialog(this);
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("size");
        signInAnonymously();
        // Read from the database to find the size of storage, number of images present
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String value = dataSnapshot.getValue(String.class);
                onlineSize = value;
                Log.d("d", "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read availability
                Log.w("d", "Failed to read availability.", error.toException());
            }
        });
        A = (Button) findViewById(R.id.A);
        A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity1();
            }
        });

        B = (Button) findViewById(R.id.B);
        B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });

        C = (Button) findViewById(R.id.C);
        C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity3();
            }
        });

        communitybtn = (Button) findViewById(R.id.Community);
        communitybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitycom();
            }
        });
        signOut = findViewById(R.id.sign_out);
        profilepic = findViewById(R.id.profileimage);
        Glide.with(this)
                .load(googleAccount.getPhotoUrl())
                .into(profilepic);
        signOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                googleSignInClient.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        //On Succesfull signout we navigate the user back to LoginActivity
                        Intent intent = new Intent(infoStart.this, activity_login.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                });
            }
        });
    }
    public void popup2(View v){
        myDialog.setContentView(R.layout.popup_window2);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView name;
        TextView date;
        TextView email;
        name =(TextView) myDialog.findViewById(R.id.name);
        date =(TextView) myDialog.findViewById(R.id.email);
        email =(TextView) myDialog.findViewById(R.id.datejoined);
        name.setText("Name: " + googleAccount.getDisplayName() );
        email.setText("Email: " + googleAccount.getEmail());
        date.setText("User Signed Up On: " + "2019.09.15");
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }
    public void openActivity1() {
        Intent intent = new Intent(this, StartActivity.class);
        startActivity(intent);
    }
    public void openActivity2() {
        Intent intent = new Intent(this, ResultsActivity.class);
        startActivity(intent);
    }
    public void openActivity3() {
        ShowPopup5();
    }
    public void openActivitycom() {
        Intent intent = new Intent(this, OnlineActivity.class);
        startActivity(intent);
    }
    public void signInAnonymously(){
        mAuth.signInAnonymously().addOnSuccessListener(this, new OnSuccessListener<AuthResult>() {
            @Override public void onSuccess(AuthResult authResult) {
                // do your stuff
            }
        }) .addOnFailureListener(this, new OnFailureListener() {
            @Override public void onFailure(@NonNull Exception exception) {
                Log.e("TAG", "signInAnonymously:FAILURE", exception);
            }
        });
    }
    public void ShowPopup5() {
        //Toast.makeText(this,"lol",Toast.LENGTH_SHORT).show();

        myDialog.setContentView(R.layout.popup_window5);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView about;
        about =(TextView) myDialog.findViewById(R.id.about);
        about.setText("ABOUT: \n" +"MADE BY TEAM AX\n" + "GRADUATION PROJECT \n2019.09.15");
        myDialog.show();
    }
}
