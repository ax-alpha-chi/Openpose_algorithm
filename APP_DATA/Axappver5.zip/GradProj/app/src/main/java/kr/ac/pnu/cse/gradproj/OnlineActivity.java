package kr.ac.pnu.cse.gradproj;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;

import java.util.Arrays;
import java.util.Collections;

import static kr.ac.pnu.cse.gradproj.infoStart.onlineSize;


public class OnlineActivity extends AppCompatActivity {

    static StorageReference[] arraystorage;
    int size;
    int i = 0;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Online Gallery");

        setContentView(R.layout.activity_online);
        size = Integer.parseInt(onlineSize);
        arraystorage = new StorageReference[Integer.parseInt(Integer.toString(size-1))];
        //assigns firebasestorage references to all images on the online storage
        for (i = 0; i < size ; i++) {
            if(i==0);
            else
                arraystorage[i-1] = FirebaseStorage.getInstance().getReference(i + ".gif");
        }
        reverse(arraystorage);
        //views all the files in storage in listview
        GridView listView = (GridView) findViewById(R.id.usage_example_listview);
        listView.setAdapter(
                new OnlineImageListAdapter(
                        this,
                        arraystorage
                )
        );
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(OnlineActivity.this,PhotoOnlineActivity.class);
                intent.putExtra("filename",position);
                startActivity(intent);
            }
        });
    }
    void reverse(StorageReference a[]){
            Collections.reverse(Arrays.asList(a));
    }
    //saves the location from metadata of the online files on arrays
}
