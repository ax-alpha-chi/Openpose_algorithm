package kr.ac.pnu.cse.gradproj;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;


public class activity_login extends AppCompatActivity {

    private ImageView imgView_logo ;
    RelativeLayout rellay1, line2;
    Handler handler = new Handler();
    Runnable runnavle = new Runnable() {
        @Override
        public void run() {
            rellay1.setVisibility(View.VISIBLE);
            line2.setVisibility(View.VISIBLE);
        }
    };
    public static GoogleSignInAccount googleAccount;
    public static GoogleSignInClient googleSignInClient;
    Button googleSignInButton;
    private static final String TAG = "AndroidClarified";
    private static final int MY_PERMISSIONS_REQUEST = 100;
    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("AX exerice");
        //REQUEST for permission and the code for intent for sign in.
        requestStoragePermission();
        setContentView(R.layout.activity_login);


        rellay1 = (RelativeLayout) findViewById(R.id.rellay1);
        line2 = (RelativeLayout) findViewById(R.id.rellay2);
        handler.postDelayed(runnavle, 2000);

        imgView_logo = (ImageView) findViewById(R.id.imgView_logo);
        googleSignInButton = findViewById(R.id.loginbtn);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestIdToken("337070546920-qron1lcr1hsvv49cjjok7kjvq0qr3ktl.apps.googleusercontent.com")
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);
        googleSignInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signInIntent = googleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, 101);
            }
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK)
            switch (requestCode) {
                case 101:
                    try {
                        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                        GoogleSignInAccount account = task.getResult(ApiException.class);
                        googleAccount = account;
                        onLoggedIn(account);
                    } catch (ApiException e) {
                        Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
                    }
                    break;
            }
    }
    //On successful login proceed to profile activity.
    private void onLoggedIn(GoogleSignInAccount googleSignInAccount) {
        Intent intent = new Intent(this, infoStart.class);
        intent.putExtra(infoStart.GOOGLE_ACCOUNT, googleSignInAccount);
        startActivity(intent);
        finish();
    }
    //checks if already signed in on start and proceed to profile page
    @Override
    public void onStart() {
        super.onStart();
        GoogleSignInAccount alreadyloggedAccount = GoogleSignIn.getLastSignedInAccount(this);
        if (alreadyloggedAccount != null) {
            Toast.makeText(this, alreadyloggedAccount.getDisplayName() + " Already Logged In", Toast.LENGTH_SHORT).show();
            googleAccount = alreadyloggedAccount;
            onLoggedIn(alreadyloggedAccount);
        } else {
            Log.d(TAG, "Not logged in");
        }
    }

}
