package com.group14.picadventure;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;

import static com.group14.picadventure.Login.googleAccount;
import static com.group14.picadventure.OnlineActivity.arraystorage;
import static com.group14.picadventure.OnlineActivity.onlineLatitudes;
import static com.group14.picadventure.OnlineActivity.onlineLongitudes;
import static com.group14.picadventure.SelectActivity.eatFoodyImages;
import static com.group14.picadventure.SelectActivity.latitudes;
import static com.group14.picadventure.SelectActivity.longitudes;
import static com.group14.picadventure.SelectActivity.mountainsRef;
import static com.group14.picadventure.SelectActivity.myRef;
import static com.group14.picadventure.SelectActivity.numberofphotos1;
import static com.group14.picadventure.SelectActivity.onlineSize;


public class PhotoActivity extends AppCompatActivity {
    private ImageView imageView1;
    public Button infoBtn;
    public Button updBtn;
    public Button mapBtn;
    int post;
    public static FirebaseStorage storage = FirebaseStorage.getInstance();
    Dialog myDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
        setTitle("AX exerice");
        //sign in anonymously otherwise cant upload images to the storage
        setContentView(R.layout.activity_photo);
        myDialog = new Dialog(this);
        imageView1 = (ImageView) findViewById(R.id.imageview1);
        final Intent intent = getIntent();
        final int position = intent.getIntExtra("filename",0);
        post = position;
        final String path = (String)eatFoodyImages[position].getAbsolutePath();
        setTitle("Photo" + path.substring(path.lastIndexOf("/")+1) );
        //nametext.setText("Name = " + path.substring(path.lastIndexOf("/")+1));
        //displays the location information
        //loctext.setText("Location = lat :"+ Double.toString(latitudes[position]) + " long :" + Double.toString(longitudes[position]));
        updBtn =(Button)findViewById(R.id.updBut);
        mapBtn =(Button)findViewById(R.id.map);
        infoBtn =(Button)findViewById(R.id.info);
        //this section handles the uploading of the file
        //and changing the meta data accordingly
        updBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StorageReference storageRef = storage.getReference();
                final int size = Integer.parseInt(onlineSize);
                StorageReference mountainsRef = storageRef.child(size + ".jpg");
                Uri file = Uri.fromFile(new File(path));
                UploadTask uploadTask = mountainsRef.putFile(file);
                onlineSize = Integer.toString(size + 1 ) ;

                myRef.setValue(onlineSize);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                        updatelocation(position,size);
                        // ...
                    }
                });
                ShowPopup2();
            }
        });
        mapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchmap(position);
            }
        });
        mapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchmap(position);
            }
        });
        infoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowPopup(latitudes[position],longitudes[position], path.substring(path.lastIndexOf("/")+1));
            }
        });

        //views the selected image from the information provided(location of the click)
        Glide
                .with(PhotoActivity.this)
                .load(eatFoodyImages[position])
                .into(imageView1);
    }
    public void ShowPopup(double lat,double longi, String name) {
        //Toast.makeText(this,"lol",Toast.LENGTH_SHORT).show();
        myDialog.setContentView(R.layout.popup_window);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView lattext;
        TextView longtext;
        TextView nametext;
        lattext =(TextView) myDialog.findViewById(R.id.loclat);
        longtext =(TextView) myDialog.findViewById(R.id.loclong);
        nametext =(TextView) myDialog.findViewById(R.id.name);
        longtext.setText("Latititude: + " + lat);
        lattext.setText("Latititude: + " + longi);
        nametext.setText("Name: " + name);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }
    public void ShowPopup2() {
        //Toast.makeText(this,"lol",Toast.LENGTH_SHORT).show();
        myDialog.setContentView(R.layout.popup_window2);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }

    void launchmap(int position){
        Intent intent = new Intent(this, PointMapActivity.class);
        intent.putExtra("lat",latitudes[position]);
        intent.putExtra("long",longitudes[position]);
        this.startActivity(intent);
    }
    void updatelocation(int position, int size){
        numberofphotos1 = Integer.toString(Integer.parseInt(numberofphotos1) + 1);
        StorageReference storageRef1 = FirebaseStorage.getInstance().getReference(size + ".jpg");
        StorageMetadata metadata = new StorageMetadata.Builder()
                .setContentType("image/jpg")
                .setCustomMetadata("latitude",Double.toString(latitudes[position]))
                .setCustomMetadata("longitude",Double.toString(longitudes[position]))
                .setCustomMetadata("commentsize","0")
                .setCustomMetadata("uploader",googleAccount.getDisplayName())
                .build();
        storageRef1.updateMetadata(metadata)
                .addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                    @Override
                    public void onSuccess(StorageMetadata storageMetadata) {
                        // Updated metadata is in storageMetadata
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Uh-oh, an error occurred!
                    }
                });
        metadata = new StorageMetadata.Builder()
                .setContentType("image/jpg")
                .setCustomMetadata("numberofphotos",numberofphotos1)
                .build();
        mountainsRef.updateMetadata(metadata)
                .addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                    @Override
                    public void onSuccess(StorageMetadata storageMetadata) {
                        // Updated metadata is in storageMetadata
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Uh-oh, an error occurred!
                    }
                });
    }
}
